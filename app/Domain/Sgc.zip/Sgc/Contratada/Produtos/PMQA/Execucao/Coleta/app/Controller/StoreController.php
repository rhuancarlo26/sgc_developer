<?php

namespace App\Domain\Sgc\Contratada\Produtos\PMQA\Execucao\Coleta\app\Controller;

use App\Domain\Sgc\Contratada\Produtos\PMQA\Execucao\Coleta\app\Requests\StoreRequest;
use App\Domain\Sgc\Contratada\Produtos\PMQA\Execucao\Coleta\app\Services\ColetaService;
use App\Models\Contrato;
use App\Models\ServicoPmqaCampanha;
use App\Models\Servicos;
use App\Models\SgcPmqa;
use App\Models\SgcPmqaCampanha;
use App\Shared\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;

class StoreController extends Controller
{
    public function __construct(private readonly ColetaService $coletaService)
    {
    }

    public function index(Contrato $contrato, string $produto, SgcPmqa $pmqa, SgcPmqaCampanha $campanha, StoreRequest $request): RedirectResponse
    {
        $post = [];

        $post['campanha_ponto_id'] = $request->validated('campanha_ponto_id');
        $post['dt_coleta'] = $request->validated('dt_coleta');
        $post['coleta'] = $request->validated('coleta');

        if ($request->validated('coleta') === true) {
            $post['numero_amostra'] = '';
            $post['preservacao_amostra'] = '';
            $post['acondicionamento_amostra'] = '';
            $post['transporte_amostra'] = '';
            $post['observacao'] = $request->validated('observacao');
        } else {
            $post['numero_amostra'] = $request->validated('numero_amostra');
            $post['preservacao_amostra'] = $request->validated('preservacao_amostra');
            $post['acondicionamento_amostra'] = $request->validated('acondicionamento_amostra');
            $post['transporte_amostra'] = $request->validated('transporte_amostra');
            $post['observacao'] = '';
        }

        $response = $this->coletaService->store($post);

        return to_route('contratos.contratada.sgc.pmqa.execucao.coleta.create', ['contrato' => $contrato->id, 'produto' => $produto, 'pmqa' => $pmqa->id, 'campanha' => $campanha->id, 'ponto' => $request->campanha_ponto_id])->with('message', $response['request']);
    }
}
