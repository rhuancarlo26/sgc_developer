<?php

namespace App\Domain\Sgc\Contratada\Produtos\PMQA\Execucao\Coleta\app\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreRequest extends FormRequest
{
    public function rules(): array
    {
        $request = (object)request()->all();
        $regras = [];

        $regras['campanha_ponto_id'] = 'required';
        $regras['dt_coleta'] = 'required';
        $regras['coleta'] = 'required';

        if ($request->coleta === true) {
            $regras['observacao'] = 'required';
        } else {
            $regras['numero_amostra'] = 'required';
            $regras['preservacao_amostra'] = 'required';
            $regras['acondicionamento_amostra'] = 'required';
            $regras['transporte_amostra'] = 'required';
        }

        return $regras;
    }

    public function messages(): array
    {
        return [];
    }

    public function authorize(): bool
    {
        return true;
    }
}
